package com.example.orders_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OrdersApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
